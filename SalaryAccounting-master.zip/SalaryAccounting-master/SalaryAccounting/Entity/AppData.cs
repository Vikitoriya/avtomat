﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalaryAccounting.Entity
{
    public static class AppData
    {
        public static Entities context = new Entities();
        public static View_1 userSave = new View_1();
    }
    
}
